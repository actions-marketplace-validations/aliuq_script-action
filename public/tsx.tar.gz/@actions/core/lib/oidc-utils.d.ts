export declare class OidcClient {
    private static createHttpClient;
    private static getRequestToken;
    private static getIDTokenUrl;
    private static getCall;
    static getIDToken(audience?: string): Promise<string>;
}
