export declare function getProxyUrl(reqUrl: URL): URL | undefined;
export declare function checkBypass(reqUrl: URL): boolean;
